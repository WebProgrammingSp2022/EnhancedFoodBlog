
let Data = function(name,grade) {
    this.name = name;
    this.grade = grade;
 
}

module.exports = Data;